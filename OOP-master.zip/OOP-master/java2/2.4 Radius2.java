class Radius2 {
    
    public static void main(String[] args) {
        System.out.println("Radius is 4 = " + (3.14 * 4 * 4));
    }
    
}